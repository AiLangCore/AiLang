# Getting Started (Agent Procedure)

## Purpose

Run build and verification flows with deterministic outputs.

## Preconditions

- Execute from repo root.
- Shell has execute permission for scripts.

## Procedure

1. Build runtime:
```bash
./build.sh
```
2. Execute golden suite:
```bash
./test.sh
```
3. Run a program:
```bash
./tools/ailang run samples/cli-fetch/project.aiproj -- Fort\ Worth
```
4. Scaffold a new project:
```bash
./tools/ailang init ./.tmp/MyApp --template cli
```
5. Build bytecode from project/source:
```bash
./tools/ailang build samples/cli-fetch/project.aiproj --out ./.tmp/build-cli-fetch
```
6. Publish wasm package (web default):
```bash
./tools/ailang publish samples/cli-fetch/project.aiproj --target wasm32 --out ./.tmp/publish-cli-fetch-wasm
```
7. Run compiler driver modes:
```bash
cat examples/golden/fmt_basic.in.aos | ./tools/ailang run --vm=ast src/compiler/aic.aos fmt
cat examples/golden/fmt_basic.in.aos | ./tools/ailang run --vm=ast src/compiler/aic.aos fmt --ids
cat examples/golden/check_missing_name.in.aos | ./tools/ailang run --vm=ast src/compiler/aic.aos check
cat examples/golden/run_var.in.aos | ./tools/ailang run --vm=ast src/compiler/aic.aos run
```

## Expected Output

- `build.sh`: canonical tooling bootstrap entrypoint. Default target rebuilds `tools/ailang`.
- `build.sh shared`: builds the shared AiVM native library.
- `build.sh wasm`: builds wasm runtime artifacts.
- `build.sh all`: builds all bootstrap artifacts.
- `test.sh`: canonical verification entrypoint. Ends with `overall DoD status: PASS` on success.
- `ailang init`: scaffolds a valid project layout with built-in templates (`cli`, `cli-args`).
- `aic fmt/check/run`: emits canonical AOS only.
- Source node ids are optional; canonical ids are assigned deterministically.
- `publish --target wasm32`:
  - default profile `spa` writes `index.html` + `main.js`.
  - `--wasm-profile cli` writes `run.sh` + `run.ps1`.
  - `--wasm-profile fullstack` writes a root app binary and `www/` wasm web artifacts.
    - also emits a self-contained root app binary (`./<appname>` or `.<\\appname>.exe`) for published-package execution.
    - optional override: `--wasm-fullstack-host-target <rid>`
    - project manifest override: `publishWasmFullstackHostTarget="<rid>"`
    - running the root app binary serves `www/` at `http://localhost:8080` (override with `PORT`).
  - malformed bytecode/source inputs are rejected deterministically with `DEV008` at publish time.

## Failure Codes

- `ailang run`: `0` success, `2` parse/validation error, `3` runtime error.
- `test.sh`: nonzero if any golden fails.
- Update-path blocking guard:
  - `VAL340` at validation-time
  - `RUN031` at runtime/VM-time

## Debugging Notes

- For golden verification, prefer native `ailang` execution over `dotnet .../ailang.dll` because the golden harness spawns subprocesses using the current process path.
- Native toolchain is C-only in active workflows; no C#/DLL fallback is required for command execution.
- If `./tools/ailang` is not usable in your environment, use the published native artifact:
```bash
./.artifacts/ailang-osx-arm64/ailang run --vm=ast src/compiler/aic.aos test examples/golden
```
- For wasm publish/run validation, build the wasm runtime artifact first:
```bash
./build.sh wasm
```

## Current Compile Coverage Note

- `build/run/publish` share one native compile pipeline.
- Imports-heavy project shapes may still return deterministic `DEV008` until native compile coverage completes for those constructs.

## Minimal Import Example

```aos
Program#p1 {
  Import#i1(path="./src/std/str.aos")
  Call#c1(target=concat) { Lit#l1(value="a") Lit#l2(value="b") }
}
```
